package com.example.youtube_player_app;

public class playerConfig {

    public playerConfig() {
    }

    public static final String API_KEY = "AIzaSyCcxsBCQ27yJHPWpNAEENAfC6npmBK3Lu0";

    public static String getApiKey() {
        return API_KEY;
    }
}
